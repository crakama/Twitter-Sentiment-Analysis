

class ClassTwitter(object):
    pass
