A command line program in Python.


